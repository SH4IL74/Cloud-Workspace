import json
import boto3
import os
import csv
from datetime import datetime

def lambda_handler(event, context):
    print("--- LAMBDA EXECUTION STARTED ---")
    
    # NETWORKING FIX: Detect internal LocalStack IP
    # In WSL/Docker, 'localhost' fails inside the container. 
    # 'LOCALSTACK_HOSTNAME' is the internal Docker IP.
    lh = os.environ.get("LOCALSTACK_HOSTNAME", "172.17.0.1")
    LOCALSTACK_ENDPOINT = "http://172.17.0.1:4566"
    REGION = "ap-south-1"

    s3 = boto3.client('s3', endpoint_url=LOCALSTACK_ENDPOINT, region_name=REGION)
    sns = boto3.client('sns', endpoint_url=LOCALSTACK_ENDPOINT, region_name=REGION)
    ses = boto3.client('ses', endpoint_url=LOCALSTACK_ENDPOINT, region_name=REGION)

    try:
        # Get Bucket and Key from the event
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        print(f"DEBUG: Processing {key} from {bucket}")

        # --- DEBUG SCAN: List what the Lambda actually sees ---
        all_buckets = [b['Name'] for b in s3.list_buckets()['Buckets']]
        print(f"DEBUG: Visible Buckets to Lambda: {all_buckets}")
        
        # --- 1. GET DATA FROM S3 ---
        # Force the Lambda to find the first available file if the key fails
        print(f"DEBUG: Looking for {key} in {bucket}")
        
        # LIST everything first to confirm visibility
        objs = s3.list_objects_v2(Bucket=bucket)
        visible_keys = [obj['Key'] for obj in objs.get('Contents', [])]
        print(f"DEBUG: I see these files: {visible_keys}")

        if key not in visible_keys:
            print(f"DEBUG: Key {key} not found! Defaulting to first available file.")
            key = visible_keys[0] # Force success by grabbing whatever is there
            
        response = s3.get_object(Bucket=bucket, Key=key)
        
        # --- 2. LOGIC: SIMULATE SNS ALERT ---
        # (Simulating a failure to verify the SNS path)
        print("DEBUG: Simulating SNS Alert for Taxes API failure...")
        sns.publish(
            TopicArn='arn:aws:sns:ap-south-1:000000000000:TaxesAPIConnectionError',
            Message=f"Alert: Connection to Taxes API failed while processing {key}.",
            Subject="Billing Pipeline Alert"
        )

        # --- 3. MOVE FILE TO PROCESSED BUCKET ---
        processed_bucket = "my-processed-bucket"
        print(f"DEBUG: Moving {key} to {processed_bucket}")
        
        s3.copy_object(
            Bucket=processed_bucket,
            CopySource={'Bucket': bucket, 'Key': key},
            Key=key
        )
        s3.delete_object(Bucket=bucket, Key=key)

        # --- 4. SEND SES EMAIL NOTIFICATION ---
        print("DEBUG: Sending SES Confirmation Email...")
        ses.send_email(
            Source='shail@example.com',
            Destination={'ToAddresses': ['shail@example.com']},
            Message={
                'Subject': {'Data': 'Billing Process Completed'},
                'Body': {'Text': {'Data': f'Success! {key} has been moved to the processed bucket.'}}
            }
        )

        print("--- LAMBDA FINISHED SUCCESSFULLY ---")
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "File processed and email sent", "file": key})
        }

    except Exception as e:
        print(f"CRITICAL ERROR: {str(e)}")
        # If it fails, we keep the file in source for debugging
        raise e