# Importing essential libraries
import csv
import boto3
from datetime import datetime
import os

def get_international_taxes(valid_product_lines,billing_bucket,csv_file):
    try:
        raise Exception("API failure : International taxes API is currently unavailable ")
    except Exception as error:
        LOCALSTACK_ENDPOINT = f"http://{os.environ.get('LOCALSTACK_HOSTNAME')}:4566"
        sns = boto3.client(
            'sns',
            endpoint_url = LOCALSTACK_ENDPOINT,
            region_name = 'ap-south-1'
        )
        sns_topic_arn = 'arn:aws:sns:ap-south-1:000000000000:TaxesAPIConnectionError'
        message = f"Lambda function failed to reach International taxes API for '{billing_bucket}' bucket and file '{csv_file}'"
        sns.publish(
            TopicArn = sns_topic_arn,
            Message = message,
            Subject = "Lambda API call failure"
        )
        print("Published failure to sns topic ")
        raise error
    
def lambda_handler(event,context):

    # Intialixe the s3 bucket
    lh = os.environ.get("LOCALSTACK_HOSTNAME", "localstack")
    LOCALSTACK_ENDPOINT = f"http://{lh}:4566"
    REGION_NAME = "ap-south-1"
    s3 = boto3.resource(
        's3',
        region_name = REGION_NAME,
        endpoint_url = LOCALSTACK_ENDPOINT,
        aws_access_key_id = "test",
        aws_secret_access_key = "test"
    )

    # Extract the bucket name and csv file name
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    csv_file_name = event['Records'][0]['s3']['object']['key']

    # Define the bucket name
    error_bucket = "my-error-bucket"
    processed_bucket = "my-processed-bucket"

    # Adding Debug lines
    print(f"DEBUG: Attempting to access bucket: '{bucket_name}'")
    print(f"DEBUG: Attempting to access key: '{csv_file_name}'")

    # Download the csv file,read the content,decode the content from bytes to strings and split the content into lines
    obj = s3.Object(bucket_name, csv_file_name)
    data = obj.get()['Body'].read().decode('utf-8').splitlines()

    # Intialixe the flag to false 
    error_found = False

    # Define valid product lines and currencies
    valid_product_lines = ['Bakery','Meat','Dairy']
    valid_currencies = ['USD','MXN','CAD']

    # Read the csv file and iterate through each row
    # Ignore the header
    for row in csv.reader(data[1:],delimiter = ","):
        # For each line get product_line,currency,date,bill_amount from specific columns
        date = row[6]
        product_lines = row[4]
        currency = row[7]
        bill_amount = row[8]

        # Check if date is valid,if not set error flag to True 
        try:
            datetime.strptime(date, '%Y-%m-%d')
        except ValueError:
            error_found = True
            print(f"Error in record {row} : Invalid date format : {date}")
            break

        # Check if the product line is valid
        if product_lines not in valid_product_lines:
            error_found = True
            print(f"Error in record {row}: Invalid product line : {product_lines}")
            break

        # Check if the currency is valid
        if currency not in valid_currencies:
            error_found = True
            print(f"Error in record {row}: Invalid currency : {currency}")
            break

        # Check if the bill amount is negative 
        if (bill_amount) < 0 :
            error_found = True
            print(f"Error in record {row}: Negative bill amount : {bill_amount}")
            break

        # After checking all records,if there is error in file,upload the file to error bucket and break the loop
        if error_found:
            copy_source = {'Bucket':bucket_name,'Key':csv_file_name}
            try:
                s3.meta.client.copy(copy_source,error_bucket,csv_file_name)
                print(f"File {csv_file_name} has been copied to {error_bucket} due to errors.")
                s3.Object(bucket_name, csv_file_name).delete()
                print(f"File {csv_file_name} has been deleted from {bucket_name}.")
            except Exception as e:
                print(f"Error copying file {csv_file_name} to error bucket: {str(e)}")
        # If there are no errors , print the record
        else:
            copy_source = {'Bucket': bucket_name, 'Key': csv_file_name}
            try:
                s3.meta.client.copy(copy_source, processed_bucket, csv_file_name)
                print(f"File {csv_file_name} has been moved to {processed_bucket} due to errors.")
                s3.Object(bucket_name, csv_file_name).delete()
                print(f"File {csv_file_name} has been deleted from {bucket_name}.")
            except Exception as e:
                print(f"Error copying file {csv_file_name} to error bucket: {str(e)}")